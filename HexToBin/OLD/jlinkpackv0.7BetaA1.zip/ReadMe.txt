
Unzip the zip file, Copy below Files to the JLink install folder, replace JLinkDevices.xml files;
JLink must to be 6.10 or over 6.10 version
for example: Jlink is installed to:
C:\Program Files (x86)\SEGGER\JLink


\Devices\MindMotion\MM32F003
\Devices\MindMotion\MM32F003\MM32F003_16.FLM
\Devices\MindMotion\MM32F0010
\Devices\MindMotion\MM32F0010\MM32F0010_16.FLM
\Devices\MindMotion\MM32F031
\Devices\MindMotion\MM32F031\MM32F031x4_16.FLM
\Devices\MindMotion\MM32F031\MM32F031x6_32.FLM
\Devices\MindMotion\MM32F031\MM32F031x8_64.FLM
\Devices\MindMotion\MM32F031\MM32F031xB_128.FLM
\Devices\MindMotion\MM32F032
\Devices\MindMotion\MM32F032\MM32F032x6_32.FLM
\Devices\MindMotion\MM32F032\MM32F032x8_64.FLM
\Devices\MindMotion\MM32F103
\Devices\MindMotion\MM32F103\MM32F103x8_64.FLM
\Devices\MindMotion\MM32F103\MM32F103xB_128.FLM
\Devices\MindMotion\MM32F103\MM32F103xC_256.FLM
\Devices\MindMotion\MM32F103\MM32F103xE_512.FLM
\Devices\MindMotion\MM32F0130
\Devices\MindMotion\MM32F0130\MM32F013xB_32.FLM
\Devices\MindMotion\MM32F0130\MM32F013xC_64.FLM
\Devices\MindMotion\MM32L0
\Devices\MindMotion\MM32L0\MM32L0xx_32.FLM
\Devices\MindMotion\MM32L0\MM32L0xx_64.FLM
\Devices\MindMotion\MM32L0\MM32L0xx_128.FLM
\Devices\MindMotion\MM32L3
\Devices\MindMotion\MM32L3\MM32L36x_64.FLM
\Devices\MindMotion\MM32L3\MM32L37x_128.FLM
\Devices\MindMotion\MM32L3\MM32L38x_256.FLM
\Devices\MindMotion\MM32L3\MM32L39x_512.FLM
\Devices\MindMotion\MM32SPIN05
\Devices\MindMotion\MM32SPIN05\MM32SPIN05_32.FLM
\Devices\MindMotion\MM32SPIN06
\Devices\MindMotion\MM32SPIN06\MM32SPIN06_64.FLM
\Devices\MindMotion\MM32SPIN25
\Devices\MindMotion\MM32SPIN25\MM32SPIN25_32.FLM
\Devices\MindMotion\MM32SPIN27
\Devices\MindMotion\MM32SPIN27\MM32SPIN27_128.FLM
\Devices\MindMotion\MM32W0
\Devices\MindMotion\MM32W0\MM32W05xB_32.FLM
\Devices\MindMotion\MM32W0\MM32W06xB_64.FLM
\Devices\MindMotion\MM32W0\MM32W07xB_128.FLM
\Devices\MindMotion\MM32W3
\Devices\MindMotion\MM32W3\MM32W36xB_64.FLM
\Devices\MindMotion\MM32W3\MM32W37xB_128.FLM
\Devices\MindMotion\MM32xx_M0.JLinkScript
\Devices\MindMotion\MM32xx_M3.JLinkScript
\JLinkDevices.xml

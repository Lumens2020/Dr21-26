#include "key.h"
#include "gpio.h"
#include "voice.h"
#include "eeprom.h"

//****************�����˷ſ��ƽ�ʹ�ܺ���*******************
///*���ܣ�      10msִ��һ�� �����˷ſ��ƽ�ʹ�ܿ���		 						*///
///*��ڲ�����	��																*///
///*���ڲ�����	��																				*///
//************************************************************

void Enable_OP_PIN(uint8_t enableoppin)
{
 if(enableoppin>0)
 	{
	 pbSpk_SHUT_ON;
 	}
 else
 	{
	 pbSpk_SHUT_OFF;
 	}
}


//****************����ģ��SDA�ŵ�ƽ���ƺ���*******************
///*���ܣ�      10msִ��һ�� ��������ģ��ͨѶSDA�ߵ͵�ƽ		 						*///
///*��ڲ�����	��																*///
///*���ڲ�����	��																				*///
//************************************************************

void SET_SDA_PIN(uint8_t enablesdapin)
{
 if(enablesdapin>0)
 	{
	 pbSpk_SDA_ON;
 	}
 else
 	{
	 pbSpk_SDA_OFF;
 	}
}

//****************����ģ��SCL�ŵ�ƽ���ƺ���*******************
///*���ܣ�      10msִ��һ�� ��������ģ��ͨѶSCL�ߵ͵�ƽ		 						*///
///*��ڲ�����	��																*///
///*���ڲ�����	��																				*///
//************************************************************

void SET_SCL_PIN(uint8_t enablesclpin)
{
 if(enablesclpin>0)
 	{
	 pbSpk_SCL_ON;
 	}
 else
 	{
	 pbSpk_SCL_OFF;
 	}
}
//****************����ģ��BUSY�ŵ�ƽ��ȡ����*******************
///*���ܣ�      10msִ��һ�� ��ȡ����ģ��ͨѶBUSY�ŵ�ƽ		 						*///
///*��ڲ�����	��																*///
///*���ڲ�����	��																				*///
//************************************************************
uint8_t Read_VoiceBusy_PIN(void)
{
 return (uint8_t)pbSpk_BUSY;
}
//****************����ģ��ͨѶ���亯��*******************
///*���ܣ�      200usִ��һ�� ����ģ������ݴ����߼�����		 						*///
///*��ڲ�����	KeyPara		VoicePara														*///
///*���ڲ�����	��																				*///
//************************************************************

void Line_2A_WT588F(KeyPara* keyparactl,VoicePara* voiceparactl)
{// 200us
	static uint8_t j;
	static uint8_t num_temp;
	static uint8_t voice_cnt1,voice_step,voice_num,voice_first;
	static uint16_t ddata_temp,pdata_temp;
	if(voice_step==0)
		{
		ddata_temp=voiceparactl->WT588F_data[voice_num];
		pdata_temp = ddata_temp& 0x00FF;
		ddata_temp >>= 8;
		pdata_temp <<= 8;
		ddata_temp |= pdata_temp;
		num_temp =16;
		j=0;
		voice_first=0;
		//pbSpk_SCL_OFF;				//ʱ����
		SET_SCL_PIN(0);
		if(++voice_cnt1>24)
			{
			voice_cnt1=0;
			voice_step=1;
			}
		}
	if(voice_step==1)
		{
			if((j==8)&&(voice_first==0))
				{
//				pbSpk_SCL_ON;		
//				pbSpk_SDA_ON;
				SET_SCL_PIN(1);
				SET_SDA_PIN(1);
				if(++voice_cnt1>9)
					{
					voice_step=4;
					}
				}
			else
				{
//				pbSpk_SCL_OFF;		
				SET_SCL_PIN(0);
//				if(ddata_temp&0x0001)pbSpk_SDA_ON;
//				else pbSpk_SDA_OFF;
				if(ddata_temp&0x0001)SET_SDA_PIN(1);
				else SET_SDA_PIN(0);
				voice_step=2;
				}
		}
	else if(voice_step==2)
		{
//		    pbSpk_SCL_ON;
		    SET_SCL_PIN(1);
			voice_step=3;
		}
	else if(voice_step==3)
		{
			ddata_temp=ddata_temp>>1;
			if(j<num_temp)
				{
				j++;
				voice_step=1;
				}
			else
				{
				voice_step=5;
				}
		}
	else if(voice_step==4)
		{
//		pbSpk_SCL_OFF;	
		SET_SCL_PIN(0);
		if(++voice_cnt1>23)
			{//��ʱ 5ms	 
			voice_cnt1=0;
			voice_step=1;
			voice_first=1;
			}
		}
	if(voice_step==5)
		{
//		pbSpk_SCL_ON;		
//		pbSpk_SDA_ON;
		SET_SCL_PIN(1);
		SET_SDA_PIN(1);
		voice_step=0;
		if(voice_num<voiceparactl->WT588F_step)
			{
			voice_num++;
			}
		else
			{
			keyparactl->bFastVoiceFlag = 0;
			
			if(voiceparactl->uiVolumePromptValue==voiceparactl->uiPreVolumePromptValue)
				{
				if(voiceparactl->uiTonePromptValue==PROMPT_VOLUME_LOW_MP3)
					{
					voiceparactl->uiVolumePromptValue=VOLUME_ADJUSTMENT_3;
					voiceparactl->uiPreVolumePromptValue=0;
					}
				else if(voiceparactl->uiTonePromptValue==PROMPT_VOLUME_HIGH_MP3)
					{
					voiceparactl->uiVolumePromptValue=VOLUME_ADJUSTMENT_A;
					voiceparactl->uiPreVolumePromptValue=0;
					}
				else if(voiceparactl->uiTonePromptValue==PROMPT_CLOSE_VOLUME_MP3)
					{
					voiceparactl->uiVolumePromptValue=VOLUME_ADJUSTMENT_OFF;
					voiceparactl->uiPreVolumePromptValue=0;
					}
				}
			else
				{
				voiceparactl->uiVolumePromptValue=0;
				voiceparactl->uiPreVolumePromptValue=0;
				}
			voiceparactl->uiTonePromptValue=0;
			voiceparactl->uiPreTonePromptValue=voiceparactl->uiTonePromptValue;
			voiceparactl->uiSecondTonePromptValue = 0;
			voiceparactl->uiThirdTonePromptValue  = 0;
			voiceparactl->ucLanguageValue = voiceparactl->ucKeyLanguageValue;
			voice_num=0;
			}
		}
}

//****************����ģ��ͨѶ���ݴ�������*******************
///*���ܣ�      200usִ��һ�� ����ģ���ͨѶ���ݴ���		 						*///
///*��ڲ�����	KeyPara		VoicePara	 Eeprom_TypeDef													*///
///*���ڲ�����	��																				*///
//************************************************************

void Play_WT588F(KeyPara* keyparactl,VoicePara* voiceparactl,Eeprom_TypeDef* eepromparactl)
{
	static uint16_t uiVoicetemp1,uiVoicetemp2,uiVoicetemp3;

//	pbSpk_SHUT_OFF;
		
	if((keyparactl->bFastVoiceFlag==1)||(Read_VoiceBusy_PIN()>0))
//		if((KeyVar.bFastVoiceFlag==1)||(pbSpk_BUSY==1))
	  {	  
	   if(voiceparactl->bVolumeOFFFlag==1)
	   	{
		voiceparactl->uiTonePromptValue=0;
		voiceparactl->uiPreTonePromptValue=voiceparactl->uiTonePromptValue;
		voiceparactl->uiSecondTonePromptValue = 0;
		voiceparactl->uiThirdTonePromptValue  = 0;
		voiceparactl->ucLanguageValue = voiceparactl->ucKeyLanguageValue;
	   	}
	   if(voiceparactl->uiPreTonePromptValue!=voiceparactl->uiTonePromptValue)
		{
		    if(voiceparactl->uiTonePromptValue==PROMPT_OPEN_VOLUME_MP3)
		    	{
//		    	pbSpk_SHUT_ON;
				Enable_OP_PIN(1);
				voiceparactl->bVolumeOFFFlag=0;
				voiceparactl->bVolumeOFFFlagback=0;
		    	}
			if(voiceparactl->uiTonePromptValue>=0x10)uiVoicetemp1 = voiceparactl->uiTonePromptValue+(voiceparactl->ucLanguageValue*0x2a);
			else uiVoicetemp1 =voiceparactl->uiTonePromptValue;
			uiVoicetemp2 = voiceparactl->uiSecondTonePromptValue+(voiceparactl->ucLanguageValue*0x2a);
			uiVoicetemp3 = voiceparactl->uiThirdTonePromptValue+(voiceparactl->ucLanguageValue*0x2a);					
			if(voiceparactl->uiSecondTonePromptValue==0)
			{
				voiceparactl->WT588F_step=1;
				voiceparactl->WT588F_data[0]=STOP_NOW_VOICE;
				voiceparactl->WT588F_data[1]=uiVoicetemp1;
			}
			else if(voiceparactl->uiThirdTonePromptValue==0)
			{
				voiceparactl->WT588F_step=4;
				voiceparactl->WT588F_data[0]=STOP_NOW_VOICE;
				voiceparactl->WT588F_data[1]=CONTINUOUS_NOW_VOICE;
				voiceparactl->WT588F_data[2]=uiVoicetemp1;
				voiceparactl->WT588F_data[3]=CONTINUOUS_NOW_VOICE;
				voiceparactl->WT588F_data[4]=uiVoicetemp2;
			}
			else 
			{
				voiceparactl->WT588F_step=6;
				voiceparactl->WT588F_data[0]=STOP_NOW_VOICE;
				voiceparactl->WT588F_data[1]=CONTINUOUS_NOW_VOICE;
				voiceparactl->WT588F_data[2]=uiVoicetemp1;
				voiceparactl->WT588F_data[3]=CONTINUOUS_NOW_VOICE;
				voiceparactl->WT588F_data[4]=uiVoicetemp2;
				voiceparactl->WT588F_data[5]=CONTINUOUS_NOW_VOICE;
				voiceparactl->WT588F_data[6]=uiVoicetemp3;
			}	
			Line_2A_WT588F(keyparactl,voiceparactl); 
		}
	   else if(voiceparactl->uiPreVolumePromptValue !=voiceparactl->uiVolumePromptValue)
	   	{
	   	   if(voiceparactl->uiVolumePromptValue==VOLUME_ADJUSTMENT_OFF)
	   	   	{
		      voiceparactl->bVolumeOFFFlag=1;
//	   	   	  if(pbSpk_BUSY==1)
			  if(Read_VoiceBusy_PIN()>0)
	   	   	  	{
	   	   	  	 if(++voiceparactl->uiOffVoiceCnt>OFF_VOICE_DEF)
	   	   	  	 	{
//	   	   	         pbSpk_SHUT_OFF;
					 Enable_OP_PIN(0);
			         voiceparactl->uiPreVolumePromptValue =0;
			         voiceparactl->uiVolumePromptValue=0;
					 voiceparactl->uiOffVoiceCnt=0;
	   	   	  	 	}
	   	   	  	}
	   	   	}
		   else
		   	{
			   voiceparactl->WT588F_step=0;
			   voiceparactl->WT588F_data[0]=voiceparactl->uiVolumePromptValue;
			   Line_2A_WT588F(keyparactl,voiceparactl);	
			   if(Read_VoiceBusy_PIN()>0)
//			   if(pbSpk_BUSY==1)
				 {
				  if(voiceparactl->bVolumeOFFFlagback)voiceparactl->bVolumeOFFFlag=1;
			     }
		   	}		   
	   	}
		else if(eepromparactl->bEnableEEpromFlag)
			{
//			Write_EEPROM();
			keyparactl->bFastVoiceFlag = 0;			
			}
		else
			{
			keyparactl->bFastVoiceFlag = 0;			
			}
	}
}


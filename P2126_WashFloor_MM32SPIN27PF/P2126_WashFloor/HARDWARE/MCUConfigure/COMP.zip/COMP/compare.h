#ifndef _COMPARE_H_
#define _COMPARE_H_


#include <stdio.h>
#include "HAL_conf.h"
#include "HAL_device.h"










void Comp_Config(void);
#endif

